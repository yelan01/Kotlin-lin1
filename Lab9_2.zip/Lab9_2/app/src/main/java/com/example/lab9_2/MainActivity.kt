package com.example.lab9_2

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var btnCalculate: Button
    private lateinit var edHeight: EditText
    private lateinit var edWeight: EditText
    private lateinit var edAge: EditText

    private lateinit var btnBoy: RadioButton
    private lateinit var btnGirl: RadioButton

    private lateinit var tvWeightResult: TextView
    private lateinit var tvFatResult: TextView
    private lateinit var tvBmiResult: TextView

    private lateinit var llProgress: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var tvProgress: TextView

    private val uiScope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setListeners()
    }

    /** 綁定 UI 元件 */
    private fun bindViews() {
        btnCalculate = findViewById(R.id.btnCalculate)

        edHeight = findViewById(R.id.edHeight)
        edWeight = findViewById(R.id.edWeight)
        edAge = findViewById(R.id.edAge)

        btnBoy = findViewById(R.id.btnBoy)
        btnGirl = findViewById(R.id.btnGirl)

        tvWeightResult = findViewById(R.id.tvWeightResult)
        tvFatResult = findViewById(R.id.tvFatResult)
        tvBmiResult = findViewById(R.id.tvBmiResult)

        llProgress = findViewById(R.id.llProgress)
        progressBar = findViewById(R.id.progressBar)
        tvProgress = findViewById(R.id.tvProgress)
    }

    /** 設定按鈕事件 */
    private fun setListeners() {
        btnCalculate.setOnClickListener {

            val height = edHeight.text.toString().toFloatOrNull()
            val weight = edWeight.text.toString().toFloatOrNull()
            val age = edAge.text.toString().toIntOrNull()

            if (height == null || weight == null || age == null) {
                Toast.makeText(this, "請輸入完整資料", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val isMale = btnBoy.isChecked

            startBodyCheckAnimation(height, weight, age, isMale)
        }
    }

    /** 啟動 Coroutine 非同步動畫 */
    private fun startBodyCheckAnimation(height: Float, weight: Float, age: Int, isMale: Boolean) {

        llProgress.visibility = View.VISIBLE
        progressBar.progress = 0
        tvProgress.text = "0%"

        uiScope.launch {

            // 進度條動畫
            for (i in 1..100) {
                progressBar.progress = i
                tvProgress.text = "$i%"

                delay(15)  // 動畫速度
            }

            llProgress.visibility = View.GONE

            // 計算與顯示結果
            showResults(height, weight, age, isMale)
        }
    }

    /** 計算結果並顯示 */
    private fun showResults(height: Float, weight: Float, age: Int, isMale: Boolean) {
        val bmi = weight / (height / 100f * height / 100f)
        val standardWeight = (height - 80) * 0.7f
        val fatRate = if (isMale)
            (1.2f * bmi) + (0.23f * age) - 16.2f
        else
            (1.2f * bmi) + (0.23f * age) - 5.4f

        tvWeightResult.text = "標準體重：${String.format("%.1f", standardWeight)} kg"
        tvFatResult.text = "體脂肪率：${String.format("%.1f", fatRate)} %"
        tvBmiResult.text = "BMI：${String.format("%.1f", bmi)}"
    }

    override fun onDestroy() {
        super.onDestroy()
        uiScope.cancel()
    }
}
