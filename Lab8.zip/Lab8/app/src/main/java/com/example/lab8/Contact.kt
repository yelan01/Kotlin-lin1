package com.example.lab8

// 設計新的類別定義聯絡人的資料結構
data class Contact (
    // 姓名
    val name: String,
    // 電話
    val phone: String
)
